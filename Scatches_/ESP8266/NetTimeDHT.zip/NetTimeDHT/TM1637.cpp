#include <Arduino.h>
#ifdef ESP8266
#include <pgmspace.h>
#else
#include <avr/pgmspace.h>
#endif
#include "TM1637.h"

const uint8_t ADDR_AUTO = 0x40;
const uint8_t ADDR_FIXED = 0x44;
const uint8_t STARTADDR = 0xC0;

TM1637::TM1637(int8_t pinCLK, int8_t pinDIO, uint8_t brightness) {
  _pinCLK = pinCLK;
  _pinDIO = pinDIO;
  _brightness = constrain(brightness, 0, 7);
  pinMode(_pinCLK, OUTPUT);
  pinMode(_pinDIO, OUTPUT);
}

void TM1637::display(uint8_t pos, uint8_t segments) {
  if (pos < 4) {
    _start();
    _writeByte(ADDR_FIXED);
    _stop();
    _start();
    _writeByte(STARTADDR + pos);
    _writeByte(segments);
    _stop();
    _start();
    _writeByte(0x88 | _brightness);
    _stop();
  }
}

void TM1637::display(uint32_t segments) {
  _start();
  _writeByte(ADDR_AUTO);
  _stop();
  _start();
  _writeByte(STARTADDR);
  for (int8_t i = 0; i < 4; i++) {
    _writeByte(segments >> (8 * i));
  }
  _stop();
  _start();
  _writeByte(0x88 | _brightness);
  _stop();
}

void TM1637::displayNum(int16_t num, bool leadingZero, bool colon) {
  uint32_t data;

  if ((num < -999) || (num > 9999)) {
    data = 0x50791C3F; // Over
  } else {
    bool minus = num < 0;
    if (minus)
      num *= -1;
    data = (uint32_t)digitToSegments(num % 10) << 24;
    num /= 10;
    if (leadingZero || (num != 0))
      data |= (uint32_t)digitToSegments(num % 10) << 16;
    num /= 10;
    if (leadingZero || (num != 0))
      data |= (uint32_t)digitToSegments(num % 10) << 8;
    num /= 10;
    if (minus) {
      data |= MINUS;
    } else {
      if (leadingZero || (num != 0))
        data |= digitToSegments(num % 10);
    }
    if (colon)
      data |= COLON;
  }
  display(data);
}

uint8_t TM1637::digitToSegments(int8_t digit) {
  static const uint8_t digits[10] PROGMEM = { 0B00111111, 0B00000110, 0B01011011, 0B01001111, 0B01100110, 0B01101101, 0B01111101, 0B0000111, 0B01111111, 0B01101111 };

  if (digit < 0)
    return MINUS;
  else if (digit < 10)
    return pgm_read_byte(&digits[digit]);
  else
    return 0;
}

inline void TM1637::_bitDelay() {
  delayMicroseconds(50);
}

void TM1637::_start() {
  digitalWrite(_pinCLK, HIGH);
  digitalWrite(_pinDIO, HIGH);
  digitalWrite(_pinDIO, LOW);
  digitalWrite(_pinCLK, LOW);
}

void TM1637::_stop() {
  digitalWrite(_pinCLK, LOW);
  digitalWrite(_pinDIO, LOW);
  digitalWrite(_pinCLK, HIGH);
  digitalWrite(_pinDIO, HIGH);
}

bool TM1637::_writeByte(uint8_t data) {
  for (int8_t i = 0; i < 8; i++) {
    digitalWrite(_pinCLK, LOW);
    digitalWrite(_pinDIO, data & 0x01);
    data >>= 1;
    digitalWrite(_pinCLK, HIGH);
  }
  digitalWrite(_pinCLK, LOW); // wait for the ACK
  digitalWrite(_pinDIO, HIGH);
  digitalWrite(_pinCLK, HIGH);
  pinMode(_pinDIO, INPUT);
  _bitDelay();
  bool ack = digitalRead(_pinDIO);
  if (! ack) {
    pinMode(_pinDIO, OUTPUT);
    digitalWrite(_pinDIO, LOW);
  }
  _bitDelay();
  pinMode(_pinDIO, OUTPUT);
  _bitDelay();

  return ack;
}
