#ifndef __DATE_H
#define __DATE_H

#include <WString.h>

void parseUnixTime(uint32_t unixtime, int8_t& hour, int8_t& minute, int8_t& second, uint8_t& weekday, int8_t& day, int8_t& month, int16_t& year);

String timeToStr(int8_t hour, int8_t minute, int8_t second);
String timeToStr(uint32_t unixtime);
String dateToStr(int8_t day, int8_t month, int16_t year);
String dateToStr(uint32_t unixtime);
String timeDateToStr(int8_t hour, int8_t minute, int8_t second, int8_t day, int8_t month, int16_t year);
String timeDateToStr(uint32_t unixtime);
String dateTimeToStr(int8_t day, int8_t month, int16_t year, int8_t hour, int8_t minute, int8_t second);
String dateTimeToStr(uint32_t unixtime);

#endif
