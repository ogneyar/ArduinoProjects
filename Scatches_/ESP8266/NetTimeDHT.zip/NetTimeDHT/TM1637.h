#ifndef __TM1637_H
#define __TM1637_H

const uint8_t MINUS = 0B01000000;
const uint32_t COLON = 0x00008000;

class TM1637 {
public:
  TM1637(int8_t pinCLK, int8_t pinDIO, uint8_t brightness = 2);
  void setBrightness(uint8_t brightness) {
    _brightness = constrain(brightness, 0, 7);
  }
  void clear() {
    display(0);
  }
  void display(uint8_t pos, uint8_t segments);
  void display(uint32_t segments);
  void displayNum(int16_t num, bool leadingZero = false, bool colon = false);
  void operator= (int16_t num) {
    displayNum(num);
  }
  static uint8_t digitToSegments(int8_t digit);
private:
  void _bitDelay();
  void _start();
  void _stop();
  bool _writeByte(uint8_t data);

  int8_t _pinCLK;
  int8_t _pinDIO;
  uint8_t _brightness;
};

#endif
